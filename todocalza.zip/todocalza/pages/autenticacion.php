<?php
include '../config.php';
include '../usuario.php';

session_start();

// Si el usuario ya está autenticado, redirigirlo según su rol
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] == 'admin') {
        header("Location: http://localhost/todocalza/pages/adminProductos.php");
    } else {
        header("Location: http://localhost/todocalza/pages/perfilUsuario.php");
    }
    exit();
}

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $usuario = new Usuario($conexion, $email, $password);

    if ($usuario->iniciar_sesion()) {
        if ($_SESSION['role'] == 'admin') {
            header("Location: http://localhost/todocalza/pages/adminProductos.php");
        } else {
            header("Location: http://localhost/todocalza/pages/perfilUsuario.php");
        }
        exit();
    } else {
        $error_message = "El correo electrónico o la contraseña son incorrectos.";
    }
}

$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autenticación</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/inicio.css">
    <!-- Enlace al CDN de Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
    <nav>
        <ul class="nav-list">
            <li><a href="http://localhost/todocalza/index.php">Inicio</a></li>
            <li><a href="http://localhost/todocalza/pages/productos.php">Catálogo</a></li>
            <li><a href="http://localhost/todocalza/pages/moduloC.php">Carrito</a></li>
            <li><a href="http://localhost/todocalza/pages/contactos.php">Contáctanos</a></li>
        </ul>
    </nav>
    <div class="container">
        <h1>BIENVENIDO A LA PÁGINA DE AUTENTICACIÓN</h1>
        <form method="post" action="http://localhost/todocalza/pages/autenticacion.php">
            <label for="email">INGRESE SU CORREO ELECTRÓNICO</label>
            <input type="email" id="email" name="email" placeholder="EJ. CALZATODO123@GMAIL.COM" required>
            <label for="password">INGRESE SU CONTRASEÑA</label>
            <input type="password" id="password" name="password" placeholder="EJ. 123456CALZA" required>
            <button type="submit">INICIAR SESIÓN</button>
            <p>¿NO TIENE UNA CUENTA? <a href="http://localhost/todocalza/pages/registro.php">CREAR UNA</a></p>
            <p><a href="http://localhost/todocalza/pages/recuperar_contrasena.php">¿OLVIDÓ SU CONTRASEÑA?</a> </p>
            <?php if(!empty($error_message)) echo "<p class='error'>$error_message</p>"; ?>
        </form>
    </div>

    <footer class="footer">
        &copy; 2024 TODOCALZA. Todos los derechos Reservados.
    </footer>
</body>
</html>





