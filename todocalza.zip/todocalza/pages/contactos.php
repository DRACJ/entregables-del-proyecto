<?php include '../config.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Contact Us</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/contac2.css">
    <!-- Enlace al CDN de Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>   
    <header class="header">
        <h1>Contáctanos</h1>
    </header>

    <nav>
        <ul class="nav-list">
            <li><a href="http://localhost/todocalza/index.php">Inicio</a></li>
            <li><a href="http://localhost/todocalza/pages/productos.php">Catálogo</a></li>
            <li><a href="http://localhost/todocalza/pages/moduloC.php">Carrito</a></li>
            <li><a href="http://localhost/todocalza/pages/contactos.php">Contáctanos</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="contact-box">
            <center><h2>Ubicación</h2></center>
            <div class="contact-info">
                <p>Av. Las Américas # 6N-54</p>
                <p>Colombia, Armenia, 12345</p>
            </div>
        </div>
        <div class="contact-box">
            <center><h2>Información de Contacto</h2></center>
            <div class="contact-info">
                <p>PBX: 601-7358456</p>
                <p>Teléfonos: 312-254-7785 ----- 321-854-9654</p>
                <p>Correo: Todocalza123@gmail.com</p>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="contact-box">
            <center><h2>Envíanos un Mensaje</h2></center>
            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "todocalza_2024";
                $port = 3306;

                $conn = new mysqli($servername, $username, $password, $dbname, $port);

                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }

                $nombre = $_POST['nombre'];
                $email = $_POST['email'];
                $mensaje = $_POST['mensaje'];

                $sql = "INSERT INTO mensajes (nombre, email, mensaje)
                        VALUES ('$nombre', '$email', '$mensaje')";

                if ($conn->query($sql) === TRUE) {
                    echo "<div class='success'>Mensaje enviado exitosamente</div>";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }

                $conn->close();
            }
            ?>
            <form method="post" action="contactos.php">
                <label for="nombre">Nombre</label>
                <input type="text" id="nombre" name="nombre" placeholder="Tu nombre" required>
                <label for="email">Correo Electrónico</label>
                <input type="email" id="email" name="email" placeholder="Tu correo electrónico" required>
                <label for="mensaje">Mensaje</label>
                <textarea id="mensaje" name="mensaje" placeholder="Escribe tu mensaje aquí" required></textarea>
                <button type="submit">Enviar Mensaje</button>
            </form>
        </div>
    </div>

    <footer class="footer">
        &copy; 2024 TODOCALZA. Todos los derechos Reservados.
    </footer>
</body>
</html>
