<?php
include __DIR__ . '/../config.php';

class Registro {
    private $conexion;

    public function __construct($conexion) {
        $this->conexion = $conexion;
    }

    public function insertarUsuario($fullname, $document_type, $document_number, $email, $telephone, $password, $rol) {
        // Escapar datos para prevenir inyección SQL
        $fullname = $this->conexion->real_escape_string($fullname);
        $document_type = $this->conexion->real_escape_string($document_type);
        $document_number = $this->conexion->real_escape_string($document_number);
        $email = $this->conexion->real_escape_string($email);
        $telephone = $this->conexion->real_escape_string($telephone);
        $password = $this->conexion->real_escape_string($password);

        // Preparar consulta SQL
        $sql = $this->conexion->prepare("INSERT INTO usuario (nombre_completo, tipo_documento, numero_documento, correo_electronico, telefono, contrasena, role)
                                         VALUES (?, ?, ?, ?, ?, ?, ?)");

        // Vincular parámetros y ejecutar consulta
        $sql->bind_param("sssssss", $fullname, $document_type, $document_number, $email, $telephone, $password, $rol);

        if ($sql->execute()) {
            return true;
        } else {
            throw new Exception("Error al registrar el usuario: " . $this->conexion->error);
        }
    }
}

// Solo ejecutar la lógica del formulario si no estamos en modo CLI (pruebas unitarias)
if (php_sapi_name() != 'cli') {
    $error_message = '';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fullname = $_POST['fullname'];
        $document_type = $_POST['document-type'];
        $document_number = $_POST['document-number'];
        $email = $_POST['email'];
        $telephone = $_POST['telephone'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm-password'];

        if ($password !== $confirm_password) {
            $error_message = "Las contraseñas no coinciden.";
        } else {
            try {
                $registro = new Registro($conexion);
                $registro->insertarUsuario($fullname, $document_type, $document_number, $email, $telephone, $password, 'usuario');
                header("Location: http://localhost/todocalza/pages/autenticacion.php");
                exit();
            } catch (Exception $e) {
                $error_message = $e->getMessage();
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/registro.css">
</head>
<body>
    <nav>
        <ul class="nav-list">
            <li><a href="http://localhost/todocalza/index.php">Inicio</a></li>
            <li><a href="productos.php">Catálogo</a></li>
            <li><a href="moduloC.php">Carrito</a></li>
            <li><a href="contactos.php">Contáctanos</a></li>
        </ul>
    </nav>
    <div class="container">
        <h1>BIENVENIDO A LA PÁGINA DE REGISTRO</h1>
        <?php
        if (!empty($error_message)) {
            echo "<div class='error'>$error_message</div>";
        }
        ?>
        <form method="post" action="registro.php" onsubmit="return validatePassword()">
            <label for="fullname">INGRESE SU NOMBRE COMPLETO</label>
            <input type="text" id="fullname" name="fullname" placeholder="EJ. JORGE VARGAS" required>
            <label for="document-type">ELIJA TIPO DE DOCUMENTO</label>
            <select id="document-type" name="document-type" required>
                <option value="cc">CC</option>
                <option value="ce">CE</option>
                <option value="ti">TI</option>
            </select>
            <label for="document-number">INGRESE SU NÚMERO DE DOCUMENTO</label>
            <input type="text" id="document-number" name="document-number" placeholder="INGRESE SOLO NÚMEROS" required>
            <label for="email">INGRESE SU CORREO ELECTRÓNICO</label>
            <input type="email" id="email" name="email" placeholder="EJ. CALZATODO123@GMAIL.COM" required>
            <label for="telephone">INGRESE SU TELÉFONO</label>
            <input type="text" id="telephone" name="telephone" placeholder="EJ. B/3122548954" required>
            <label for="password">INGRESE UNA CONTRASEÑA</label>
            <input type="password" id="password" name="password" placeholder="EJ. 123456CALZA" required>
            <label for="confirm-password">CONFIRME SU CONTRASEÑA</label>
            <input type="password" id="confirm-password" name="confirm-password" placeholder="Repita su contraseña" required>
            <button type="submit">CREAR PERFIL</button>
        </form>
    </div>

    <footer class="footer">
        &copy; 2024 TODOCALZA. Todos los derechos Reservados.
    </footer>

    <script>
    function validatePassword() {
        var password = document.getElementById("password").value;
        var confirmPassword = document.getElementById("confirm-password").value;
        if (password !== confirmPassword) {
            alert("Las contraseñas no coinciden.");
            return false;
        }
        return true;
    }
    </script>
</body>
</html>



