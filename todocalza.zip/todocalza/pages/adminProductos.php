<?php
include '../config.php';

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: http://localhost/todocalza/pages/autenticacion.php");
    exit();
}



// Definir la ruta absoluta al directorio raíz del proyecto
define('ROOT_PATH', realpath(dirname(__FILE__) . '/..'));
define('UPLOAD_DIR', ROOT_PATH . '/uploads');

// Función para eliminar un producto
if (isset($_GET['delete_product'])) {
    $productId = $_GET['delete_product'];
    $sql = "DELETE FROM productos WHERE id_productos=?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param('i', $productId);
    $stmt->execute();
    header("Location: adminProductos.php");
    exit();
}

// Función para editar un producto
if (isset($_GET['edit_product'])) {
    $productId = $_GET['edit_product'];
    $sql = "SELECT * FROM productos WHERE id_productos=?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param('i', $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
}

// Función para guardar producto editado o nuevo
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productId = $_POST['productId'];
    $productName = $_POST['productName'];
    $productDescription = $_POST['productDescription'];
    $productPrice = $_POST['productPrice'];
    $productImage = ''; // Inicializar la variable de la imagen

    // Verificar si se proporcionó una URL de imagen o si se cargó un archivo de imagen
    if (!empty($_POST['productImageUrl'])) {
        $productImage = $_POST['productImageUrl']; // Usar la URL proporcionada
    } elseif (isset($_FILES['productImage']) && $_FILES['productImage']['error'] == 0) {
        // Subir la imagen si se seleccionó un archivo
        if (!is_dir(UPLOAD_DIR)) {
            if (!mkdir(UPLOAD_DIR, 0777, true)) {
                echo "Error al crear el directorio de cargas.";
                exit();
            }
        }
        $productImage = 'uploads/' . uniqid('', true) . "." . pathinfo($_FILES['productImage']['name'], PATHINFO_EXTENSION);
        $targetPath = UPLOAD_DIR . '/' . basename($productImage);
        if (!move_uploaded_file($_FILES['productImage']['tmp_name'], $targetPath)) {
            echo "Error al mover el archivo cargado.";
            exit();
        }
    }

    // Determinar si es una actualización o una inserción
    if (!empty($productId)) {
        // Actualizar el producto
        $sql = "UPDATE productos SET nombre=?, descripcion=?, precio=?, imagenUrl=? WHERE id_productos=?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param('ssdsi', $productName, $productDescription, $productPrice, $productImage, $productId);
    } else {
        // Insertar un nuevo producto
        $sql = "INSERT INTO productos (nombre, descripcion, precio, imagenUrl) VALUES (?, ?, ?, ?)";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param('ssds', $productName, $productDescription, $productPrice, $productImage);
    }

    // Ejecutar la consulta preparada
    if ($stmt->execute()) {
        // Redireccionar a la página de administración de productos
        header("Location: adminProductos.php");
        exit();
    } else {
        // Error al ejecutar la consulta
        echo "Error al guardar el producto: " . $stmt->error;
    }
}

// Obtener todos los productos
$sql = "SELECT * FROM productos";
$resultado = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración de Productos - Tienda de Calzado</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/adminProductos.css">
    <!-- Enlace al CDN de Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1>Administración de Productos</h1>
    <div class="item"><a href="../logout.php">Desconectarse</a></div> <!-- Botón de cierre de sesión -->
    <div class="item"><a href="http://localhost/todocalza/pages/productos.php">Catalogo</a></div>
    <div class="item"><a href="http://localhost/todocalza/pages/moduloC.php">moduloCompra</a></div>

    <section class="product-form">
        <h2>Crear/Modificar Producto</h2>
        <form method="POST" action="adminProductos.php" enctype="multipart/form-data">
            <input type="hidden" name="productId" value="<?php echo isset($product['id_productos']) ? htmlspecialchars($product['id_productos']) : '' ?>">
            <label for="productName">Nombre del Producto:</label>
            <input type="text" id="productName" name="productName" value="<?php echo isset($product['nombre']) ? htmlspecialchars($product['nombre']) : '' ?>" required>

            <label for="productDescription">Descripción:</label>
            <textarea id="productDescription" name="productDescription" required><?php echo isset($product['descripcion']) ? htmlspecialchars($product['descripcion']) : '' ?></textarea>

            <label for="productPrice">Precio:</label>
            <input type="number" id="productPrice" name="productPrice" value="<?php echo isset($product['precio']) ? $product['precio'] : '' ?>" required>

            <label for="productImageUrl">URL de la Imagen del Producto:</label>
            <input type="text" id="productImageUrl" name="productImageUrl" value="<?php echo isset($product['imagenUrl']) ? htmlspecialchars($product['imagenUrl']) : '' ?>">

            <label for="productImage">O cargar imagen desde el escritorio:</label>
            <input type="file" id="productImage" name="productImage">
            <?php if (isset($product['imagenUrl']) && !empty($product['imagenUrl'])): ?>
                <div class="image-preview">
                    <img src="../<?php echo htmlspecialchars($product['imagenUrl']); ?>" alt="Vista previa de la imagen" style="max-width: 200px; margin-top: 20px;">
                </div>
            <?php endif; ?>

            <button type="submit">Guardar Producto</button>
        </form>
    </section>

    <section class="product-list">
        <h2>Lista de Productos</h2>
        <table class="table table-striped">
            <thead>
            <tr>
                <th>Imagen</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Acciones</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if ($resultado->num_rows > 0) {
                while ($fila = $resultado->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td><img src='../" . htmlspecialchars($fila['imagenUrl']) . "' alt='" . htmlspecialchars($fila['nombre']) . "' style='max-width: 100px;'></td>";
                    echo "<td>" . htmlspecialchars($fila['nombre']) . "</td>";
                    echo "<td>" . htmlspecialchars($fila['descripcion']) . "</td>";
                    echo "<td>$" . number_format($fila['precio'], 0, ',', '.') . " COP</td>";
                    echo "<td class='action-buttons'>";
                    echo "<a href='?edit_product=" . $fila['id_productos'] . "'>Editar</a>";
                    echo "<a href='?delete_product=" . $fila['id_productos'] . "' onclick='return confirm(\"¿Estás seguro de que deseas eliminar este producto?\")'>Eliminar</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No hay productos</td></tr>";
            }
            ?>
            </tbody>
        </table>
    </section>
</div>
</body>
</html>



