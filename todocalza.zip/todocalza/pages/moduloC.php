<?php

//Iniciar la sesión si no está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    // Redirigir al usuario a la página de autenticación si no está autenticado
    header("Location: http://localhost/todocalza/pages/autenticacion.php");
    exit();
}

// Obtener el ID de usuario de la sesión
$id_usuario = $_SESSION['user_id'];

// Incluir configuración
include dirname(__FILE__) . '/../config.php';


?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>www.modulopagostodocalza.com</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/moduloC.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Protest+Riot&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <span class="fondo">almacenes todocalza, visitanos y lleva siempre lo mejor para tu familia 
        <a id="link" target="_blank" href="productos.php">pincha aquí!</a>
    </span>
    <nav>
        <ul class="nav-list">
            <li><a href="http://localhost/todocalza/">Inicio</a></li>
            <li><a href="productos.php">Catálogo</a></li>
            <li><a href="moduloC.php">Carrito</a></li>
            <li><a href="contactos.php">Contáctanos</a></li>
        </ul>
    </nav>

    <div class="compra">REALIZAR COMPRA</div>

    <?php
    // Datos de conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "todocalza_2024";
    $port = 3306;

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nombre = $_POST['nombre'];
        $email = $_POST['email'];
        $telefono = $_POST['telefono'];
        $medio_pago = $_POST['medio_pago'];
        $tipo_banco = $_POST['tipo_banco'];
        $num_tarjeta = isset($_POST['num_tarjeta']) ? $_POST['num_tarjeta'] : '';
        $cvv = isset($_POST['cvv']) ? $_POST['cvv'] : '';
    
        // Datos de conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "todocalza_2024";
        $port = 3306;
    
        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname, $port);
    
        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }
    
        // Guardar datos en la tabla compra_usuario
        $sql = "INSERT INTO compra_usuario (nombre, email, telefono, medio_pago, tipo_banco, num_tarjeta, cvv, id_usuario) VALUES ('$nombre', '$email', '$telefono', '$medio_pago', '$tipo_banco', '$num_tarjeta', '$cvv', '$id_usuario')";
    
        if ($conn->query($sql) === TRUE) {
            echo "<script>
                    alert('Muchas gracias por su compra, el comprobante de la transacción le llegará al correo en unos momentos. En caso de no recibirlo, lo invitamos a comunicarse a través de nuestras líneas de servicio al cliente: tel 3122547798-3218547866');
                    window.location.href = 'moduloC.php';
                  </script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    
        $conn->close();
    }
    

    // Consultar productos de la tabla productos
    $conn = new mysqli($servername, $username, $password, $dbname, $port);

    // Verificar conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $sql = "SELECT nombre, precio FROM productos";
    $result = $conn->query($sql);

    $productos = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $productos[] = $row;
        }
    } else {
        echo "No hay productos disponibles.";
    }

    $conn->close();
    ?>

    <form action="moduloC.php" method="post" id="pagoForm">
        <label for="nombre">Nombres Cliente:</label>
        <input class="text" id="nombre" name="nombre" placeholder="ejemplo: Juan Carlos Medina" required>
        <br>
        <label for="email">Email:</label>
        <input class="text" id="email" name="email" placeholder="ejemplo: juanmedina@gmail.com" required>
        <br>
        <label for="telefono">Teléfono:</label>
        <input class="text" id="telefono" name="telefono" placeholder="ejemplo: 3023507085" required>
        <br>
        <label for="medio_pago">Medio de Pago:</label>
        <select class="pago" id="medio_pago" name="medio_pago" onchange="mostrarCamposTarjeta()" required>
            <option value="paypal">PayPal</option>
            <option value="psp">PSP</option>
            <option value="tarjeta_credito">Tarjeta de Crédito</option>
            <option value="tarjeta_debito">Tarjeta de Débito</option>
        </select>
        <br>
        <div id="camposTarjeta" style="display: none;">
            <label for="num_tarjeta">Número de Tarjeta:</label>
            <input class="text" id="num_tarjeta" name="num_tarjeta" placeholder="ejemplo: 1234 5678 9012 3456">
            <br>
            <label for="cvv">CVV:</label>
            <input class="text" id="cvv" name="cvv" placeholder="ejemplo: 123">
            <br>
        </div>
        <label for="tipo_banco">Tipo de Banco:</label>
        <select class="pago" id="tipo_banco" name="tipo_banco" required>
            <option value="no aplica">No aplica</option>
            <option value="davivienda">Davivienda</option>
            <option value="bbva">BBVA</option>
            <option value="bancolombia">Bancolombia</option>
        </select>
        <br>
        <input id="button" type="submit" value="Realizar Pago">
    </form>

    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th
                <th>Precio Unitario (COP)</th>
                <th>Cantidad</th>
                <th>Valor Total (COP)</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <select id="zapatos" onchange="actualizarPrecio()">
                        <?php
                        foreach ($productos as $producto) {
                            echo '<option value="' . $producto['precio'] . '">' . $producto['nombre'] . '</option>';
                        }
                        ?>
                    </select>
                </td>
                <td id="precioUnitario">0 COP</td>
                <td><input type="number" id="cantidad" value="0" oninput="actualizarSubtotal(this.value)"></td>
                <td id="valorTotal">0.00 COP</td>
                <td><button type="button" onclick="reiniciarContadores(this)">Reiniciar</button></td>    
            </tr>
        </tbody>
    </table>
    
    <table>
        <tr>
            <td>Compra sin IVA</td>
            <td id="compraSinIVA">0.00 COP</td>
        </tr>
        <tr>
            <td>IVA 16%</td>
            <td id="iva16">0.00 COP</td>
        </tr>
        <tr>
            <td>Valor Total de Compra</td>
            <td id="valorTotalCompra">0.00 COP</td>
        </tr>
    </table>
    
    <script>
        let precioUnitario = {};
        <?php
        foreach ($productos as $producto) {
            echo "precioUnitario['" . $producto['nombre'] . "'] = " . $producto['precio'] . ";";
        }
        ?>

        function actualizarSubtotal(cantidad) {     
            const opcionSeleccionada = document.getElementById("zapatos").value;
            const subtotal = parseInt(opcionSeleccionada) * cantidad;
            document.getElementById("valorTotal").textContent = subtotal.toLocaleString("es-CO", { style: "currency", currency: "COP" });
            actualizarCompraSinIVA(subtotal);
        }

        function reiniciarContadores(button) {
            const row = button.parentNode.parentNode;
            const cantidadInput = row.querySelector("input[type='number']");
            cantidadInput.value = 0;
            actualizarSubtotal(0);
        }

        function actualizarCompraSinIVA(subtotal) {
            const iva = subtotal * 0.16;
            const compraSinIVA = subtotal - iva;
            document.getElementById("compraSinIVA").textContent = compraSinIVA.toLocaleString("es-CO", { style: "currency", currency: "COP" });
            document.getElementById("iva16").textContent = iva.toLocaleString("es-CO", { style: "currency", currency: "COP" });
            document.getElementById("valorTotalCompra").textContent = subtotal.toLocaleString("es-CO", { style: "currency", currency: "COP" });
        }

        function actualizarPrecio() {
            const select = document.getElementById("zapatos");
            const precio = select.value;
            document.getElementById("precioUnitario").textContent = parseInt(precio).toLocaleString("es-CO", { style: "currency", currency: "COP" });
            actualizarSubtotal(document.getElementById("cantidad").value);
        }

        function mostrarCamposTarjeta() {
            const medioPago = document.getElementById("medio_pago").value;
            const camposTarjeta = document.getElementById("camposTarjeta");
            if (medioPago === "tarjeta_credito" || medioPago === "tarjeta_debito") {
                camposTarjeta.style.display = "block";
            } else {
                camposTarjeta.style.display = "none";
            }
        }
    </script>

    <button type="button" onclick="mostrarHistorial()">Mostrar Historial de Pagos</button>

    <script>
        function mostrarHistorial() {
            alert("Función no implementada");
        }
    </script>
</body>
</html>



