<?php
include '../config.php';

// Verifica si se recibieron datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $productName = $_POST['productName'];
    $productDescription = $_POST['productDescription'];
    $productPrice = $_POST['productPrice'];
    
    // Verifica si se subió una imagen
    if (isset($_FILES['productImage'])) {
        $productImage = $_FILES['productImage'];

        // Obtiene la información del archivo de imagen
        $imageName = $productImage['name'];
        $imageTmpName = $productImage['tmp_name'];
        $imageSize = $productImage['size'];
        $imageError = $productImage['error'];

        // Verificar si no hay errores en la carga de la imagen
        if ($imageError === 0) {
            // Genera un nombre único para la imagen
            $imageFullName = uniqid('', true) . "." . pathinfo($imageName, PATHINFO_EXTENSION);
            $imageDestination = "../uploads/" . $imageFullName;

            // Mueve el archivo de imagen al directorio de subida
            move_uploaded_file($imageTmpName, $imageDestination);

            // Insertar los datos del producto en la base de datos
            $sql = "INSERT INTO productos (nombre, descripcion, precio, imagenUrl) VALUES (?, ?, ?, ?)";
            $stmt = $conexion->prepare($sql);
            $stmt->bind_param('ssds', $productName, $productDescription, $productPrice, $imageFullName);
            $stmt->execute();

            // Redirecciona a la página de administración de productos
            header("Location: adminProductos.php");
            exit();
        } else {
            echo "Error al cargar la imagen.";
        }
    } else {
        echo "Debe seleccionar una imagen.";
    }
}
?>

