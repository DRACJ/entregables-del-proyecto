<?php
$hasPurchased = false; // Establecer que el usuario no ha realizado compras

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensaje de Compra</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/secciones.css">
</head>
<body>
    <div class="mensaje">
        <h1>Ufffsss,</h1>
        <p>Lo sentimos, <?php echo ($hasPurchased ? '' : 'aún no has realizado compras, por lo cual no tienes nada en el momento.'); ?></p>
        <p>Gracias por tu tiempo. <?php echo ($hasPurchased ? '' : 'Te invitamos a hacer tu primera compra desde nuestra página <a href="https://www.todocalza.com">www.todocalza.com</a>.'); ?></p>
    </div>
</body>
</html>





