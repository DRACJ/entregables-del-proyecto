<?php include '../config.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidad de TODOCALZA</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/politicas.css">
    <!-- Enlace al CDN de Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  
  <nav>
    <ul class="nav-list">
      <li><a href="http://localhost/todocalza/">Inicio</a></li>
      <li><a href="productos.php">Catálogo</a></li>
      <li><a href="moduloC.php">Carrito</a></li>
      <li><a href="contactos.php">Contáctanos</a></li>
    </ul>
  </nav>

  <div class="container">
    <h1>Política de Privacidad de TODOCALZA</h1>
    
    <p>En TODOCALZA, entendemos la importancia de la privacidad y nos comprometemos a proteger la información personal de nuestros usuarios. Esta Política de Privacidad describe cómo recopilamos, usamos y protegemos la información que recopilamos a través de nuestro sitio web mientras ofrecemos nuestros servicios de venta de zapatos en línea.</p>
    
    <h2>Información que Recopilamos:</h2>
    <ul>
      <li><strong>Información de Registro:</strong></li>
      <p>Al registrarse en nuestro sitio web, podemos solicitar cierta información personal, como nombre, dirección de correo electrónico, dirección de envío y preferencias de calzado. Esta información nos ayuda a proporcionarle una experiencia personalizada y a procesar sus pedidos de manera eficiente.</p>
      
      <li><strong>Información de Pago:</strong> </li>
      <p>Al realizar una compra, recopilamos información de pago, como detalles de tarjetas de crédito o información de PayPal. Esta información se utiliza únicamente para procesar los pagos y completar las transacciones.</p>

      <li><strong>Información Automática:</strong> </li>
      <p>Al igual que muchos otros sitios web, recopilamos automáticamente cierta información sobre su dispositivo y su actividad en nuestro sitio
      utilizando cookies y tecnologías similares. Esto puede incluir su dirección IP, tipo de navegador, páginas visitadas y preferencias de idioma.</p>
    </ul>

    <h2>Cambios en la Política de Privacidad:</h2>
    <p>Nos reservamos el derecho de actualizar esta Política de Privacidad en cualquier momento. Se le notificará sobre cualquier cambio mediante la publicación de la Política de Privacidad actualizada en nuestro sitio web. Le recomendamos que revise periódicamente esta página para estar al tanto de cualquier cambio.</p>
  </div>

  <footer class="footer">
    &copy; 2024 TODOCALZA. Todos los derechos Reservados.
  </footer>
</body>
</html>



