<?php
include '../config.php'; // configuración para la conexión a la base de datos

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: http://localhost/todocalza/pages/autenticacion.php");
    exit();
}

// obtener el id de la sesion
$userId = $_SESSION['user_id'];
// $user = null; para pruebas

// Obtener información del usuario
$sql = "SELECT nombre_completo, correo_electronico, telefono FROM usuario WHERE id_usuario = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param('i', $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $user = $result->fetch_assoc();
} else {
    echo "<p>Error: Usuario no encontrado.</p>";
    exit();
}

// Actualizar información del usuario si se envían los formularios
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Actualizar correo electrónico
    if (isset($_POST['email'])) {
        $correo = $_POST['email'];
        $sql = "UPDATE usuario SET correo_electronico = ? WHERE id_usuario = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param('si', $correo, $userId);
        $stmt->execute();
        $user['correo_electronico'] = $correo; // Actualizar el correo en la variable de usuario
    }
    // Actualizar teléfono
    if (isset($_POST['telefono'])) {
        $telefono = $_POST['telefono'];
        $sql = "UPDATE usuario SET telefono = ? WHERE id_usuario = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param('si', $telefono, $userId);
        $stmt->execute();
        $user['telefono'] = $telefono; // Actualizar el teléfono en la variable de usuario
    }
}

$stmt->close();
$conexion->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/perfilU.css">
    <!-- Enlace al CDN de Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
    <div id="profile-container">
        <div class="section">
            <h2 class="section-title">Cuenta</h2>
            <div class="item">Nombre: <?php echo htmlspecialchars($user['nombre_completo']); ?></div>
            <form method="post" action="">
                <div class="item">Correo Electrónico: 
                    <input type="email" name="email" value="<?php echo htmlspecialchars($user['correo_electronico']); ?>">
                    <button type="submit">Actualizar</button>
                </div>
            </form>
            <form method="post" action="">
                <div class="item">Teléfono: 
                    <input type="text" name="telefono" value="<?php echo htmlspecialchars($user['telefono']); ?>">
                    <button type="submit">Actualizar</button>
                </div>
            </form>
            <div class="item"><a href="http://localhost/todocalza/pages/secciones.php">Cupones (por compras)</a></div>
            <div class="item"><a href="http://localhost/todocalza/pages/secciones.php">Tarjeta Regalo</a></div>
            <div class="item"><a href="http://localhost/todocalza/pages/secciones.php">Mis pedidos</a></div>
        </div>

        <div class="section">
            <h2 class="section-title">Sobre nosotros</h2>
            <div class="item"><a href="http://localhost/todocalza/pages/quienes_somos.php">¿Quienes somos?</a></div>
            <div class="item"><a href="http://localhost/todocalza/pages/club_todocalza.php">¿Qué es el club Todocalza?</a></div>
        </div>
        <div class="section">
            <h2 class="section-title">Mi Perfil</h2>
            <div class="item"><a href="http://localhost/todocalza/pages/moduloC.php">Comprar</a></div>
            <div class="item"><a href="http://localhost/todocalza/pages/productos.php">Catalogo</a></div>
            <div class="item"><a href="../logout.php">cerrar sesión</a></div>
        </div>
    </div>
</body>
</html>

