<?php
include '../config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CATÁLOGO</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/productos.css">
    <!-- Enlace al CDN de Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <center><h1>Catálogo</h1></center>
    <hr>
    <nav>
        <ul class="nav-list">
            <li><a href="http://localhost/todocalza/">Inicio</a></li>
            <li><a href="http://localhost/todocalza/pages/productos.php">Catálogo</a></li>
            <li><a href="http://localhost/todocalza/pages/moduloC.php">Carrito</a></li>
            <li><a href="http://localhost/todocalza/pages/contactos.php">Contáctanos</a></li>
        </ul>
    </nav>

    <div class="product-container">
        <?php
        // Consultar los productos de la base de datos
        $sql = "SELECT nombre, descripcion, imagenUrl, ROUND(precio) AS precio FROM productos";
        $result = $conexion->query($sql);

        if ($result->num_rows > 0) {
            // Mostrar productos
            while ($row = $result->fetch_assoc()) {
                echo '<a href="http://localhost/todocalza/pages/moduloC.php" class="product-link">'; // Enlace que lleva al usuario a moduloC.php
                echo '<div class="product-card">';
                echo '<img class="product-image" src="../' . $row["imagenUrl"] . '" alt="' . $row["nombre"] . '">';
                echo '<h2>' . $row["nombre"] . '</h2>';
                echo '<p><h3>DETALLES DEL PRODUCTO</h3>';
                echo '<p>' . $row["descripcion"] . '</p>';
                echo '<p><strong>Precio: </strong>$' . number_format($row["precio"], 0, ',', '.') . ' COP</p>'; // Formato para mostrar en pesos colombianos sin decimales
                echo '</div>';
                echo '</a>'; // Cierre de la etiqueta de anclaje
            }
        } else {
            echo "No hay productos disponibles.";
        }

        $conexion->close();
        ?>
    </div>

    <div class="compra-ya">
        <p>¡Compra yaaaa!!!</p>
    </div>

    <footer class="footer">
        &copy; 2024 TODOCALZA. Todos los derechos reservados.
    </footer>
</body>
</html>



