<?php
include '../config.php';
require '../vendor/autoload.php'; // Incluir el autoload de Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);

    if ($email) {
        // Preparar la consulta para verificar si el correo existe
        $stmt = $conexion->prepare("SELECT * FROM `password_resets` WHERE email = ?");
        if (!$stmt) {
            die('Error en la preparación de la consulta: ' . $conexion->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado_consulta = $stmt->get_result()->fetch_assoc();

        // Generar un nuevo token de recuperación
        $token = md5(uniqid(rand(), true));

        if ($resultado_consulta) {
            // Si el correo electrónico existe, actualizar el token y la fecha
            $stmt = $conexion->prepare("UPDATE `password_resets` SET token = ?, created_at = CURRENT_TIMESTAMP WHERE email = ?");
            if (!$stmt) {
                die('Error en la preparación de la consulta: ' . $conexion->error);
            }
            $stmt->bind_param("ss", $token, $email);
        } else {
            // Si el correo electrónico no existe, insertar un nuevo registro
            $stmt = $conexion->prepare("INSERT INTO `password_resets` (email, token, created_at) VALUES (?, ?, CURRENT_TIMESTAMP)");
            if (!$stmt) {
                die('Error en la preparación de la consulta: ' . $conexion->error);
            }
            $stmt->bind_param("ss", $email, $token);
        }

        if ($stmt->execute()) {
            // Enviar el correo utilizando PHPMailer
            $mail = new PHPMailer(true);

            try {
                // Configuración del servidor
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com'; // SMTP server
                $mail->SMTPAuth   = true;
                $mail->Username   = 'tu_correo@gmail.com'; // Tu correo de Gmail
                $mail->Password   = 'tu_contraseña'; // Tu contraseña de Gmail
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                // Destinatarios
                $mail->setFrom('tu_correo@gmail.com', 'TODOCALZA');
                $mail->addAddress($email);

                // Contenido del correo
                $mail->isHTML(true);
                $mail->Subject = 'Recuperación de contraseña';
                $mail->Body    = "Hemos recibido una solicitud para restablecer la contraseña asociada a esta dirección de correo electrónico. Si no solicitaste esto, ignora este mensaje.<br><br>Para restablecer tu contraseña, haz clic en el siguiente enlace: <a href='http://localhost/todocalza/reset_password.php?token=$token'>Restablecer Contraseña</a><br><br>Gracias,<br>Tu equipo de TODOCALZA";

                $mail->send();
                echo '<div class="alert alert-success" role="alert">Se ha enviado un correo electrónico con instrucciones para restablecer su contraseña.</div>';
            } catch (Exception $e) {
                echo '<div class="alert alert-danger" role="alert">Error al enviar el correo electrónico. Por favor, inténtelo de nuevo más tarde.</div>';
                echo 'Mailer Error: ' . $mail->ErrorInfo;
            }
        } else {
            echo '<div class="alert alert-danger" role="alert">Error al actualizar la base de datos. Por favor, inténtelo de nuevo más tarde.</div>';
        }

        $stmt->close();
    } else {
        echo '<div class="alert alert-danger" role="alert">Correo electrónico no válido.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="http://localhost/todocalza/css/recuperar.css" rel="stylesheet">

</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Recuperar Contraseña</h3>
                    </div>
                    <div class="card-body">
                        <form method="post" action="recuperar_contrasena.php">
                            <div class="form-group">
                                <label for="email">Ingrese su Correo Electrónico</label>
                                <input type="email" id="email" name="email" class="form-control" placeholder="EJ. CALZATODO123@GMAIL.COM" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">ENVIAR CORREO DE RECUPERACIÓN</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

