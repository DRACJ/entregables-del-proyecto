<?php include '../config.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acerca de nosotros - Todocalza</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/quienesS.css"> 
    <!-- Enlace al CDN de Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
 
</head>
<body>
    <div class="container">
        <header><h1>Acerca de nosotros - Todocalza</h1></header>

        <nav>
        <ul class="nav-list">
            <li><a href="http://localhost/todocalza/index.php">Inicio</a></li>
            <li><a href="http://localhost/todocalza/pages/productos.php">Catálogo</a></li>
            <li><a href="http://localhost/todocalza/pages/moduloC.php">Carrito</a></li>
            <li><a href="http://localhost/todocalza/pages/contactos.php">Contáctanos</a></li>
        </ul>
    </nav>
    
    <div>

        <p>Todocalza es tu destino para encontrar los mejores zapatos para cualquier ocasión. Nuestro compromiso radica en ofrecerte no solo zapatos, sino experiencias. Cada par que seleccionamos cuidadosamente para nuestro catálogo está cargado de calidad y atención al detalle, garantizando que cada paso que des sea un verdadero placer.</p>

        <p>Desde las zapatillas deportivas que te acompañan en tus jornadas de ejercicio hasta los tacones que realzan tu estilo en las ocasiones más especiales, en Todocalza entendemos que el calzado no solo es un accesorio, sino una expresión de tu personalidad y un compañero indispensable en tu día a día.</p>

        <center><h2>Nuestro equipo</h2></center>

        <p>Nuestro equipo está comprometido con la calidad, la moda y la satisfacción del cliente. Trabajamos con las mejores marcas y proveedores para ofrecerte una amplia selección de zapatos de alta calidad a precios competitivos.</p>

        <p>En Todocalza, creemos en la importancia de la comodidad y el estilo. Por eso, nos esforzamos por brindarte las últimas tendencias en calzado, sin comprometer la calidad ni el confort.</p>

        <p>Explora nuestro catálogo en línea y descubre una amplia variedad de estilos, tallas y colores para toda la familia.</p>

        <center><p>¡Encuentra el par perfecto para ti en Todocalza!</p></center>
        <center><p>¡Gracias por elegir Todocalza como tu destino para comprar zapatos en línea!</p></center>

    </div>
</div>

<footer class="footer">
        &copy; 2024 TODOCALZA. Todos los derechos Reservados.
    </footer>

</body>
</html>
