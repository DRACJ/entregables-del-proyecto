<?php include '../config.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre el Club Todocalza</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/club_todocalza.css">
    <!-- Enlace al CDN de Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    
</head>
<body>
    <div class="container">
        <header><h1>Sobre el Club Todocalza</h1></header>
        

    <nav>
        <ul class="nav-list">
            <li><a href="http://localhost/todocalza/index.php">Inicio</a></li>
            <li><a href="http://localhost/todocalza/pages/productos.php">Catálogo</a></li>
            <li><a href="http://localhost/todocalza/pages/moduloC.php">Carrito</a></li>
            <li><a href="http://localhost/todocalza/pages/contactos.php">Contáctanos</a></li>
        </ul>
    </nav>

        <p>Bienvenido al Club Todocalza, En nuestro club, nos enorgullecemos de reunir a una comunidad apasionada de entusiastas del calzado que comparten una devoción común por la moda y el estilo. Nos dedicamos a celebrar la diversidad y la creatividad en el mundo del calzado, donde cada par de zapatos cuenta una historia única y refleja la personalidad de quien los lleva.</p>
        <p>Como miembros de este vibrante club, no solo compartimos una pasión por los zapatos, sino que también nos comprometemos a inspirarnos mutuamente, a explorar las últimas tendencias y a descubrir nuevas formas de expresión a través del calzado. Desde zapatillas de deporte hasta elegantes tacones, desde botas de invierno hasta sandalias de verano, aquí encontrarás un espacio donde tus gustos y preferencias son celebrados y valorados.</p>
        <p>En el Club Todocalza, nos esforzamos por ofrecerte contenido exclusivo, noticias sobre lanzamientos de productos, promociones especiales y mucho más. Únete a nosotros para estar al tanto de las últimas tendencias en calzado y formar parte de una comunidad apasionada.</p>
        <p>Únete a nosotros en este emocionante viaje y sumérgete en un mundo de moda, creatividad y autenticidad. En el Club Todocalza, no solo encontrarás un lugar para expresarte, sino también una familia de espíritus afines que comparten tu amor por los zapatos y todo lo que representan. ¡Te damos la bienvenida con los brazos abiertos a nuestra comunidad de amantes del calzado.</p>
        
        <div class="social-buttons">
            <a href="https://www.instagram.com" target="_blank"><button>Instagram</button></a>
            <a href="https://twitter.com" target="_blank"><button>Twitter</button></a>
            <a href="https://www.facebook.com" target="_blank"><button>Facebook</button></a>
        </div>
    </div>
    <footer class="footer">
        &copy; 2024 TODOCALZA. Todos los derechos Reservados.
    </footer>

</body>
</html>


