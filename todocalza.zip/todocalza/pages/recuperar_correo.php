<?php include '../config.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Correo</title>
    <link rel="stylesheet" href="http://localhost/todocalza/css/recuperar.css">
</head>
<body>
    <div class="container">
        <h1>Recuperar Correo</h1>
        <form method="post" action="recuperar_correo.php">
            <label for="username">Ingrese su Nombre de Usuario</label>
            <input type="text" id="username" name="username" placeholder="EJ. usuario123">
            <button type="submit">ENVIAR CORREO DE RECUPERACIÓN</button>
        </form>
    </div>

    <footer class="footer">
        &copy; 2024 TODOCALZA. Todos los derechos Reservados.
    </footer>
</body>
</html>
