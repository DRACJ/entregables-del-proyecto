<?php
session_start();
session_unset();
session_destroy();
echo "Cerraste sesión correctamente."; // Mensaje de depuración en el servidor
header("Location: http://localhost/todocalza/pages/autenticacion.php");
exit();
?>

