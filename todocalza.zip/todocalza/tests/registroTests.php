<?php

require 'vendor/autoload.php';
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../pages/registro.php';

class RegistroTests extends TestCase
{
    public function testInsercionUsuarioExitosa()
    {
        // Preparar datos de prueba
        $fullname = "John Doe";
        $document_type = "CC";
        $document_number = "1234567890";
        $email = "john@example.com";
        $telephone = "1234567890";
        $password = "password123";
        $rol = "usuario";

        // Simular una conexión a la base de datos (mock)
        $conexionMock = $this->createMock(mysqli::class);
        $stmtMock = $this->createMock(mysqli_stmt::class);

        // Configurar el mock para la preparación y ejecución de la consulta
        $conexionMock->expects($this->once())
            ->method('prepare')
            ->with($this->stringContains("INSERT INTO usuario"))
            ->willReturn($stmtMock);

        // Escapar los datos
        $conexionMock->expects($this->any())
            ->method('real_escape_string')
            ->will($this->returnCallback(function($value) {
                return $value; // Simular el comportamiento de real_escape_string
            }));

        // Asegúrate de que los valores esperados son correctos
        $stmtMock->expects($this->once())
            ->method('bind_param')
            ->with(
                $this->equalTo('sssssss'), 
                $this->equalTo($fullname),
                $this->equalTo($document_type),
                $this->equalTo($document_number),
                $this->equalTo($email),
                $this->equalTo($telephone),
                $this->equalTo($password),
                $this->equalTo($rol)
            )
            ->willReturn(true);

        $stmtMock->expects($this->once())
            ->method('execute')
            ->willReturn(true);

        // Crear una instancia de la clase bajo prueba (Registro)
        $registro = new Registro($conexionMock);

        // Ejecutar la función bajo prueba
        $resultado = $registro->insertarUsuario($fullname, $document_type, $document_number, $email, $telephone, $password, $rol);

        // Verificar el resultado esperado
        $this->assertTrue($resultado);
    }
}




// php vendor/bin/phpunit --testdox tests/registroTests.php
// php vendor/bin/phpunit --testdox tests/modulotest.php
