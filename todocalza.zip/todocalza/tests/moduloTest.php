<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../pages/moduloC.php';

class ModuloTest extends TestCase
{
    protected $conn;

    protected function setUp(): void
    {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "todocalza_2024";
        $port = 3306;

        $this->conn = new mysqli($servername, $username, $password, $dbname, $port);
    }

    protected function tearDown(): void
    {
        if ($this->conn instanceof mysqli) {
            $this->conn->close();
        }
    }

    // Prueba para verificar que la conexión a la base de datos se realiza correctamente
    public function testConexionBaseDatos()
    {
        // Verificar si hay errores de conexión
        if ($this->conn->connect_error) {
            $this->fail("Error de conexión: " . $this->conn->connect_error);
        }

        // Verificar que la conexión es una instancia de mysqli
        $this->assertInstanceOf(mysqli::class, $this->conn);
    }

    // Prueba para verificar que el formulario de compra se procesa correctamente
    public function testProcesamientoFormularioCompra()
    {   
        // Simulación de un valor de ID de usuario existente en la base de datos
        $id_usuario = 15;

        // Simular datos de entrada del formulario
        $_POST = [
            'nombre' => 'jorge lopez',
            'email' => 'lopezjjorgej@outlook.com',
            'telefono' => '3102826932',
            'medio_pago' => 'paypal',
            'tipo_banco' => 'davivienda',
        ];

        // Simular solicitud POST
        $_SERVER["REQUEST_METHOD"] = "POST";

        // Capturar salida de la ejecución del script
        ob_start();
        include __DIR__ . '/../pages/moduloC.php'; // Usar include en lugar de require_once
        $output = ob_get_clean();

        // Verificar que el mensaje de agradecimiento se muestra en la salida
        $this->assertStringContainsString('Muchas gracias por su compra', $output);
        $this->assertStringNotContainsString('Error:', $output); // Verificar que no hay errores
    }
}






// ./vendor/bin/phpunit --configuration phpunit.xml

// php vendor/bin/phpunit --testdox tests/moduloTest.php
