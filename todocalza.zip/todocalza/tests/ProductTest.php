<?php

use PHPUnit\Framework\TestCase;

class ProductTest extends TestCase
{
    public function testGetProducts()
    {
        // Datos de conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "todocalza_2024";
        $port = 3306;

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname, $port);

        try {
            // Verificar conexión
            if ($conn->connect_error) {
                $this->fail("Conexión fallida: " . $conn->connect_error);
            }

            // Consultar los productos de la base de datos
            $sql = "SELECT nombre, precio FROM productos";
            $result = $conn->query($sql);

            if (!$result) {
                $this->fail("Error en la consulta: " . $conn->error);
            }

            // Verificar que hay más de 0 productos
            $this->assertGreaterThan(0, $result->num_rows, "No hay productos disponibles.");

            // Opcional: Validar los datos obtenidos
            while ($row = $result->fetch_assoc()) {
                $this->assertArrayHasKey('nombre', $row, "El producto no tiene nombre.");
                $this->assertArrayHasKey('precio', $row, "El producto no tiene precio.");
            }
        } finally {
            // Cerrar la conexión
            $conn->close();
        }
    }
}


//   php vendor/bin/phpunit --testdox tests/ProductTest.php
// ./vendor/bin/phpunit --configuration phpunit.xml

