<?php
use PHPUnit\Framework\TestCase;

require 'vendor/autoload.php';

// Iniciar la sesión antes de cualquier salida
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../usuario.php';

class UsuarioTests extends TestCase {
    
    public function setUp(): void {
        ob_start();
    }

    public function tearDown(): void {
        ob_end_clean();
    }

    public function testIniciarSesionAdmin() {
        // Configurar la conexión a la base de datos para pruebas
        $conexion = new mysqli('localhost', 'root', '', 'todocalza_2024', 3306);

        // Verificar si la conexión tiene algún error
        if ($conexion->connect_error) {
            die("Connection failed: " . $conexion->connect_error);
        }

        // Intenta iniciar sesión con las credenciales de administrador reales
        $usuario = new Usuario($conexion, 'jvargas764024@cue.edu.co', 'Todo.123');

        // Ejecutar el método iniciar_sesion() y verificar el resultado
        $this->assertTrue($usuario->iniciar_sesion(), 'Inicio de sesión de administrador fallido');
    }

    public function testIniciarSesionUsuario() {
        // Configurar la conexión a la base de datos para pruebas
        $conexion = new mysqli('localhost', 'root', '', 'todocalza_2024', 3306);

        // Verificar si la conexión tiene algún error
        if ($conexion->connect_error) {
            die("Connection failed: " . $conexion->connect_error);
        }

        // Intenta iniciar sesión con las credenciales de usuario reales
        $usuario = new Usuario($conexion, 'Lopezjjorgej@outlook.com', 'Todo123');

        // Ejecutar el método iniciar_sesion() y verificar el resultado
        $this->assertTrue($usuario->iniciar_sesion(), 'Inicio de sesión de usuario fallido');
    }
}
?>


//  vendor/bin/phpunit --testdox tests/UsuarioTests.php

// ./vendor/bin/phpunit --configuration phpunit.xml

