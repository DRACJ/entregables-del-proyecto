<?php
use PHPUnit\Framework\TestCase;

require 'vendor/autoload.php';
require_once __DIR__ . '/../usuario.php';
// Iniciar la sesión antes de cualquier salida
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

class IntegrationUsuarioTests extends TestCase {
    
    public function setUp(): void {
        ob_start();
    }

    public function tearDown(): void {
        ob_end_clean();
    }

    public function testIniciarSesionAdmin() {
        // Simular datos de entrada del formulario
        $_POST = [
            'email' => 'jvargas764024@cue.edu.co',
            'password' => 'Todo.123',
        ];

        // Simular solicitud POST
        $_SERVER["REQUEST_METHOD"] = "POST";

        // Crear una instancia de la clase Usuario
        $conexion = new mysqli('localhost', 'root', '', 'todocalza_2024', 3306);
        $usuario = new Usuario($conexion, $_POST['email'], $_POST['password']);

        // Ejecutar el método iniciar_sesion()
        $resultado = $usuario->iniciar_sesion();

        // Verificar que la sesión se inicia correctamente
        $this->assertTrue($resultado, 'No se inició sesión de administrador correctamente');
        $this->assertEquals('admin', $_SESSION['role'], 'El rol de usuario no es el esperado');
    }

    public function testIniciarSesionUsuario() {
        // Simular datos de entrada del formulario
        $_POST = [
            'email' => 'Lopezjjorgej@outlook.com',
            'password' => 'Todo123',
        ];

        // Simular solicitud POST
        $_SERVER["REQUEST_METHOD"] = "POST";

        // Crear una instancia de la clase Usuario
        $conexion = new mysqli('localhost', 'root', '', 'todocalza_2024', 3306);
        $usuario = new Usuario($conexion, $_POST['email'], $_POST['password']);

        // Ejecutar el método iniciar_sesion()
        $resultado = $usuario->iniciar_sesion();

        // Verificar que la sesión se inicia correctamente
        $this->assertTrue($resultado, 'No se inició sesión de usuario correctamente');
        $this->assertEquals('usuario', $_SESSION['role'], 'El rol de usuario no es el esperado');
    }
}







//   php vendor/bin/phpunit --testdox tests/IntegrationUsuarioTests.php