<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todocalza_2024";
$port = 3306;


// Crear conexión
$conexion = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}
?>


