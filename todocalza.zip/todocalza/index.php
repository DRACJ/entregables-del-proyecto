<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Almacenes TodoCalza</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Cabin:ital@1&family=Libre+Baskerville:wght@700&family=Lilita+One&family=Shrikhand&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="http://localhost/todocalza/css/index.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Enlace al CDN de Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
    <div class="navegacion">
        <h1 class="logo">TodoCalza</h1>
        <nav>
            <ul>
                <li class="listas"><a><input type="text" placeholder="Buscar..."></a></li>
                <li class="listas"><a href="http://localhost/todocalza/pages/registro.php">Entrar/Registrarse</a><i class="fa-solid fa-user"></i></li>
                <li class="listas"><a href="http://localhost/todocalza/pages/contactos.php">Contactos</a><i class="fa-solid fa-envelope"></i></li>
                <li class="listas"><a href="http://localhost/todocalza/pages/autenticacion.php">Iniciar Sesión</a><i class="fa-solid fa-right-to-bracket"></i></li>
                <li class="listas"><a href="http://localhost/todocalza/pages/moduloC.php">Carrito</a><i class="fa-solid fa-cart-shopping"></i></li>
                <li class="listas"><a href="http://localhost/todocalza/pages/productos.php">Catálogo</a><i class="fa-solid fa-location-dot"></i></li>
            </ul>
        </nav>
    </div>

    <div class="container">
        <ul>
            <li class="arr dawn">Mujer &#x23f7;</li>
            <li class="arr dawn">Hombre &#x23f7;</li>
            <li class="arr dawn">Niño &#x23f7;</li>
            <li class="arr dawn">Niña &#x23f7;</li>
            <li class="arr dawn">Marcas &#x23f7;</li>
            <li class="arr dawn">Dotación &#x23f7;</li>
            <li class="arr dawn">Ofertas &#x23f7;</li>
        </ul>
    </div>

    <section class="container1">
        <p>Envíos gratis por compras superiores a $150.000. ¡Aplican T&C! ¡Compra ya!</p>
    </section>

    <a href="http://localhost/todocalza/pages/politicas.php">
        <button>
            <span>Políticas y Privacidad</span>
        </button>
    </a>

    <section class="container2">
        <p>Descuentos en calzado para dama</p>
    </section>

    <button>
        <span class="test">Inicio &#x2386;</span>
        <span class="test">Tienda &#x2386;</span>
        <span class="test">Mujer &#x2386;</span>
    </button>

    <span class="filtro"><i class="fa-solid fa-bars"></i>- Filtros</span> 

    <a href="http://localhost/todocalza/pages/moduloC.php" title="Shop Online"><span class="compra">Comprar en línea</span></a>

    <nav class="container3">
        <a href="http://localhost/todocalza/pages/moduloC.php"><button class="btn"><img src="./img2/image1.png" alt="Imagen 1"></button></a>
        <a href="http://localhost/todocalza/pages/moduloC.php"><button class="btn"><img src="./img2/image2.png" alt="Imagen 2"></button></a>
        <a href="http://localhost/todocalza/pages/moduloC.php"><button class="btn"><img src="./img2/image3.png" alt="Imagen 3"></button></a>
    </nav>


    <footer>
        <p class="fin">Elaborado por Jorge Vargas / Fabrizzio Martinez 2024</p>
    </footer>
</body>
</html>
