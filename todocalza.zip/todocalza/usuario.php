<?php
if (!class_exists('Usuario')) {
class Usuario {
    // ATRIBUTOS
    private $user;
    private $pass;
    private $conexion;

    // MÉTODOS
    function __construct($conexion, $_user, $_pass) {
        $this->conexion = $conexion;
        $this->user = $_user;
        $this->pass = $_pass;
    }

    function iniciar_sesion() {
        $sql_admin = "SELECT id_admin, role, correo_electronico FROM administradores WHERE correo_electronico = ? AND contrasena = ?";
        $sql_usuario = "SELECT id_usuario, role, correo_electronico FROM usuario WHERE correo_electronico = ? AND contrasena = ?";
        
        $stmt_admin = $this->prepareAndExecute($sql_admin);
        $stmt_usuario = $this->prepareAndExecute($sql_usuario);

        if ($stmt_admin->num_rows == 1) {
            return $this->handleLoginResult($stmt_admin, 'admin');
        } elseif ($stmt_usuario->num_rows == 1) {
            return $this->handleLoginResult($stmt_usuario, 'usuario');
        } else {
            return false;
        }
    }

    private function prepareAndExecute($sql) {
        $stmt = $this->conexion->prepare($sql);
        if ($stmt === false) {
            throw new Exception('Prepare failed: ' . htmlspecialchars($this->conexion->error));
        }
        $stmt->bind_param('ss', $this->user, $this->pass);
        $stmt->execute();
        return $stmt->get_result();
    }

    private function handleLoginResult($stmt, $role) {
        $row = $stmt->fetch_assoc();
        $_SESSION['user_id'] = $row['id_usuario'] ?? $row['id_admin'];
        $_SESSION['role'] = $role;
        $_SESSION['email'] = $row['correo_electronico'];
        return true;
    }

    function getUser() {
        return $this->user;
    }
}
}









